package com.livedubbg

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color as AndroidColor
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** A small draggable demo overlay. It does not control real audio processing yet. */
class FloatingPanelService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = GradientDrawable().apply {
                setColor(AndroidColor.argb(238, 13, 22, 39))
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), AndroidColor.rgb(77, 226, 208))
            }
        }
        val title = TextView(this).apply {
            text = "◉  GLAS  •  LIVE"
            setTextColor(AndroidColor.rgb(77, 226, 208))
            textSize = 12f
            setPadding(dp(4), dp(4), dp(10), dp(4))
        }
        val stop = TextView(this).apply {
            text = "×"
            textSize = 22f
            setTextColor(AndroidColor.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(9), 0, dp(9), 0)
            setOnClickListener { stopSelf() }
        }
        root.addView(title)
        root.addView(stop)
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(180)
        }
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        title.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    try { windowManager.updateViewLayout(root, params) } catch (_: Exception) { }
                    true
                }
                else -> false
            }
        }
        panel = root
        try {
            windowManager.addView(root, params)
            Toast.makeText(this, "Плаващият демонстрационен панел е активен", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            panel = null
            stopSelf()
        }
    }

    override fun onDestroy() {
        panel?.let { view -> try { windowManager.removeView(view) } catch (_: Exception) { } }
        panel = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
