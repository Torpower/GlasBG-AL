package com.livedubbg

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D31)
private val Cyan = Color(0xFF4DE2D0)
private val Purple = Color(0xFF9B8CFF)
private val Muted = Color(0xFF9AA8C2)
private val Red = Color(0xFFFF5268)
private val Green = Color(0xFF62F5A5)
private val Amber = Color(0xFFFFC857)
private val Blue = Color(0xFF58A6FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LiveDubApp(onOverlayClick = { requestOverlayPanel() }) }
    }

    private fun requestOverlayPanel() {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingPanelService::class.java))
        } else {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveDubApp(onOverlayClick: () -> Unit) {
    var source by remember { mutableStateOf("Вътрешно аудио") }
    var from by remember { mutableStateOf("Английски") }
    var to by remember { mutableStateOf("Български") }
    var voice by remember { mutableStateOf("BG • Естествен глас 01") }
    var running by remember { mutableStateOf(false) }
    var showFrom by remember { mutableStateOf(false) }
    var showTo by remember { mutableStateOf(false) }
    var showVoice by remember { mutableStateOf(false) }
    var internalAudio by remember { mutableStateOf(true) }
    var microphone by remember { mutableStateOf(false) }
    var translation by remember { mutableStateOf(true) }
    var emotion by remember { mutableStateOf(true) }
    var offlineMode by remember { mutableStateOf(true) }
    var speakerSeparation by remember { mutableStateOf(true) }

    val languages = listOf("Български", "Английски", "Немски", "Френски", "Испански", "Италиански", "Турски", "Гръцки", "Руски", "Украински", "Полски", "Румънски", "Арабски", "Китайски", "Японски", "Корейски", "Португалски", "Нидерландски", "Чешки", "Сръбски")
    val voices = listOf("BG • Естествен глас 01", "BG • Спокоен глас 02", "BG • Енергичен глас 03", "BG • Нисък глас 04", "BG • Висок глас 05")

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, secondary = Purple, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF101729), contentColor = Muted) {
                NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.GraphicEq, null) }, label = { Text("Дублаж") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.RecordVoiceOver, null) }, label = { Text("Гласове") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Color(0xFF111A30), Bg))), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Bg, modifier = Modifier.size(28.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text("GlasBG-AI", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("NEURAL AUDIO CONTROL • AI DUB", color = Muted, fontSize = 10.sp, letterSpacing = 0.8.sp)
                        }
                        Surface(color = Color(0xFF173C3B), shape = RoundedCornerShape(50)) { Text("LOCAL / AI", color = Cyan, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(132.dp).background(Color(0xFF1B2940), CircleShape), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(104.dp).background(Color(0xFF213B4A), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(54.dp))
                                }
                            }
                            Text(if (running) "ДЕМОНСТРАЦИЯ АКТИВНА" else "NEURAL DUBBING CORE", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, fontSize = 12.sp)
                            Text(if (running) "Интерфейсът е активен — AI обработката още не е свързана" else "Избери източник и езикова посока", color = Muted, fontSize = 13.sp)
                            Button(onClick = { running = !running }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF58364A) else Cyan, contentColor = if (running) Color.White else Bg), shape = RoundedCornerShape(16.dp)) {
                                Icon(if (running) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(8.dp)); Text(if (running) "Спри сесията" else "Започни дублаж", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Text("ПРОТОТИП: реалното разпознаване, превод и синтез на реч все още не са интегрирани.", color = Amber, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                    }
                }
                item {
                    SectionTitle("NEON CONTROL MATRIX", "Контролен панел")
                    Text("Светещ индикатор = включено • червен индикатор = изключено", color = Muted, fontSize = 11.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NeonControl("Вътрешен звук", Icons.Default.Smartphone, internalAudio, Cyan, Modifier.weight(1f)) { internalAudio = it }
                            NeonControl("Микрофон", Icons.Default.Mic, microphone, Red, Modifier.weight(1f)) { microphone = it }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NeonControl("AI превод", Icons.Default.Translate, translation, Green, Modifier.weight(1f)) { translation = it }
                            NeonControl("Емоции", Icons.Default.Psychology, emotion, Amber, Modifier.weight(1f)) { emotion = it }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NeonControl("Разделяне на гласове", Icons.Default.Groups, speakerSeparation, Purple, Modifier.weight(1f)) { speakerSeparation = it }
                            NeonControl("Офлайн режим", Icons.Default.CloudOff, offlineMode, Blue, Modifier.weight(1f)) { offlineMode = it }
                        }
                    }
                    OutlinedButton(onClick = onOverlayClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.OpenInNew, null, tint = Cyan)
                        Spacer(Modifier.width(8.dp))
                        Text("АКТИВИРАЙ ПЛАВАЩИЯ ПАНЕЛ")
                    }
                    Text("Android ще поиска разрешение за показване над други приложения. Плаващият панел управлява само демонстрационния интерфейс.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                }
                item {
                    SectionTitle("OFFLINE VAULT", "Езикови пакети")
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).background(Color(0xFF173342), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Inventory2, null, tint = Cyan) }
                                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                    Text("English → Български", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Локален ASR + превод + глас", color = Muted, fontSize = 11.sp)
                                }
                                Surface(color = Color(0xFF452B35), shape = RoundedCornerShape(8.dp)) { Text("НЕ Е ГОТОВ", color = Red, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) }
                            }
                            LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Cyan, trackColor = Color(0xFF263149))
                            Text("Управлението на пакетите е подготвено като интерфейс. Реални модели за офлайн реч, превод и синтез трябва да бъдат добавени отделно.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                            OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("ИЗТЕГЛИ ЕЗИКОВ ПАКЕТ — ПРЕДСТОИ") }
                        }
                    }
                }
                item {
                    SectionTitle("АУДИО ИЗТОЧНИК", "Откъде да вземем звука?")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SourceCard("Вътрешно аудио", "Звук от телефона", Icons.Default.Smartphone, source == "Вътрешно аудио", Modifier.weight(1f)) { source = "Вътрешно аудио" }
                        SourceCard("Микрофон", "Външен звук", Icons.Default.Mic, source == "Микрофон", Modifier.weight(1f)) { source = "Микрофон" }
                    }
                    if (source == "Вътрешно аудио") Text("Android позволява заснемане само на звук от приложения, които разрешават audio playback capture. Защитени приложения може да блокират записа.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp))
                }
                item {
                    SectionTitle("ЕЗИКОВА ПОСОКА", "Преведи речта")
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            LanguageDrop("От език", from, { showFrom = true })
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Icon(Icons.Default.South, null, tint = Cyan) }
                            LanguageDrop("Към език", to, { showTo = true })
                            OutlinedButton(onClick = { val tmp = from; from = to; to = tmp }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.SwapVert, null); Spacer(Modifier.width(8.dp)); Text("Размени езиците") }
                        }
                    }
                }
                item {
                    SectionTitle("ГЛАС ЗА ДУБЛАЖ", "Избери звучене")
                    Card(onClick = { showVoice = true }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(46.dp).background(Color(0xFF2A2850), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.RecordVoiceOver, null, tint = Purple) }
                            Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(voice, color = Color.White, fontWeight = FontWeight.SemiBold); Text("Български • примерен каталог", color = Muted, fontSize = 12.sp) }
                            Icon(Icons.Default.ExpandMore, null, tint = Muted)
                        }
                    }
                    Text("Броят и езиците на гласовете зависят от избрания доставчик. 1000 гласа и 1000 езика не са включени в този прототип.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
                }
                item { Spacer(Modifier.height(6.dp)); Text("GLASBG-AI  •  UI PROTOTYPE 0.2.0", color = Color(0xFF64718B), fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
            }
        }
    }

    if (showFrom) ChoiceDialog("Изходен език", languages, { from = it; showFrom = false }, { showFrom = false })
    if (showTo) ChoiceDialog("Език за дублаж", languages, { to = it; showTo = false }, { showTo = false })
    if (showVoice) ChoiceDialog("Български глас", voices, { voice = it; showVoice = false }, { showVoice = false })
}

@Composable
private fun NeonControl(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, accent: Color, modifier: Modifier = Modifier, onToggle: (Boolean) -> Unit) {
    val light = if (enabled) accent else Red
    Card(onClick = { onToggle(!enabled) }, modifier = modifier, colors = CardDefaults.cardColors(containerColor = if (enabled) Color(0xFF152338) else Color(0xFF241923)), border = androidx.compose.foundation.BorderStroke(1.dp, light.copy(alpha = if (enabled) 0.85f else 0.65f)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(36.dp).background(light.copy(alpha = 0.14f), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = light, modifier = Modifier.size(21.dp)) }
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(9.dp).background(light, CircleShape))
            }
            Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, minLines = 2, lineHeight = 16.sp)
            Text(if (enabled) "● СИСТЕМАТА Е ВКЛЮЧЕНА" else "● ИЗКЛЮЧЕНО", color = light, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp)
        }
    }
}

@Composable
private fun SectionTitle(eyebrow: String, title: String) {
    Column(Modifier.padding(bottom = 10.dp)) {
        Text(eyebrow, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SourceCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF16383D) else Panel), border = if (selected) androidx.compose.foundation.BorderStroke(1.dp, Cyan) else null, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = if (selected) Cyan else Muted, modifier = Modifier.size(26.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
            Text(if (selected) "● ИЗБРАНО" else "○ ИЗБЕРИ", color = if (selected) Cyan else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun LanguageDrop(label: String, value: String, onClick: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Muted, fontSize = 12.sp)
        OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(14.dp)) {
            Text(value, color = Color.White, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ExpandMore, null, tint = Cyan)
        }
    }
}

@Composable
private fun ChoiceDialog(title: String, choices: List<String>, onChoose: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = {
        LazyColumn(Modifier.heightIn(max = 360.dp)) { items(choices.size) { i -> TextButton(onClick = { onChoose(choices[i]) }, modifier = Modifier.fillMaxWidth()) { Text(choices[i], modifier = Modifier.fillMaxWidth()) } } }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Затвори") } }, containerColor = Panel, titleContentColor = Color.White, textContentColor = Muted)
}
